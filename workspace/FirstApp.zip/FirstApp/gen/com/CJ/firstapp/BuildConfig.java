/** Automatically generated file. DO NOT MODIFY */
package com.CJ.firstapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}